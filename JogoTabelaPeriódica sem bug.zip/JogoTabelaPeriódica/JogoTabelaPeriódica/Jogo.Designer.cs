﻿namespace JogoTabelaPeriódica
{
    partial class Jogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jogo));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtElemento = new System.Windows.Forms.TextBox();
            this.txtPontos = new System.Windows.Forms.TextBox();
            this.txtEletron = new System.Windows.Forms.TextBox();
            this.btnGeraElemento = new System.Windows.Forms.Button();
            this.btn103 = new System.Windows.Forms.Button();
            this.btn102 = new System.Windows.Forms.Button();
            this.btn101 = new System.Windows.Forms.Button();
            this.btn100 = new System.Windows.Forms.Button();
            this.btn99 = new System.Windows.Forms.Button();
            this.btn98 = new System.Windows.Forms.Button();
            this.btn97 = new System.Windows.Forms.Button();
            this.btn96 = new System.Windows.Forms.Button();
            this.btn95 = new System.Windows.Forms.Button();
            this.btn94 = new System.Windows.Forms.Button();
            this.btn93 = new System.Windows.Forms.Button();
            this.btn92 = new System.Windows.Forms.Button();
            this.btn91 = new System.Windows.Forms.Button();
            this.btn90 = new System.Windows.Forms.Button();
            this.btn89 = new System.Windows.Forms.Button();
            this.btn71 = new System.Windows.Forms.Button();
            this.btn70 = new System.Windows.Forms.Button();
            this.btn69 = new System.Windows.Forms.Button();
            this.btn68 = new System.Windows.Forms.Button();
            this.btn67 = new System.Windows.Forms.Button();
            this.btn66 = new System.Windows.Forms.Button();
            this.btn65 = new System.Windows.Forms.Button();
            this.btn64 = new System.Windows.Forms.Button();
            this.btn63 = new System.Windows.Forms.Button();
            this.btn62 = new System.Windows.Forms.Button();
            this.btn61 = new System.Windows.Forms.Button();
            this.btn60 = new System.Windows.Forms.Button();
            this.btn59 = new System.Windows.Forms.Button();
            this.btn58 = new System.Windows.Forms.Button();
            this.btn57 = new System.Windows.Forms.Button();
            this.btn118 = new System.Windows.Forms.Button();
            this.btn117 = new System.Windows.Forms.Button();
            this.btn116 = new System.Windows.Forms.Button();
            this.btn115 = new System.Windows.Forms.Button();
            this.btn114 = new System.Windows.Forms.Button();
            this.btn113 = new System.Windows.Forms.Button();
            this.btn112 = new System.Windows.Forms.Button();
            this.btn111 = new System.Windows.Forms.Button();
            this.btn110 = new System.Windows.Forms.Button();
            this.btn109 = new System.Windows.Forms.Button();
            this.btn108 = new System.Windows.Forms.Button();
            this.btn107 = new System.Windows.Forms.Button();
            this.btn106 = new System.Windows.Forms.Button();
            this.btn105 = new System.Windows.Forms.Button();
            this.btn104 = new System.Windows.Forms.Button();
            this.btn88 = new System.Windows.Forms.Button();
            this.btn87 = new System.Windows.Forms.Button();
            this.btn86 = new System.Windows.Forms.Button();
            this.btn85 = new System.Windows.Forms.Button();
            this.btn84 = new System.Windows.Forms.Button();
            this.btn83 = new System.Windows.Forms.Button();
            this.btn82 = new System.Windows.Forms.Button();
            this.btn81 = new System.Windows.Forms.Button();
            this.btn80 = new System.Windows.Forms.Button();
            this.btn79 = new System.Windows.Forms.Button();
            this.btn78 = new System.Windows.Forms.Button();
            this.btn77 = new System.Windows.Forms.Button();
            this.btn76 = new System.Windows.Forms.Button();
            this.btn75 = new System.Windows.Forms.Button();
            this.btn74 = new System.Windows.Forms.Button();
            this.btn73 = new System.Windows.Forms.Button();
            this.btn72 = new System.Windows.Forms.Button();
            this.btn56 = new System.Windows.Forms.Button();
            this.btn55 = new System.Windows.Forms.Button();
            this.btn54 = new System.Windows.Forms.Button();
            this.btn53 = new System.Windows.Forms.Button();
            this.btn52 = new System.Windows.Forms.Button();
            this.btn51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.btn49 = new System.Windows.Forms.Button();
            this.btn48 = new System.Windows.Forms.Button();
            this.btn47 = new System.Windows.Forms.Button();
            this.btn46 = new System.Windows.Forms.Button();
            this.btn45 = new System.Windows.Forms.Button();
            this.btn44 = new System.Windows.Forms.Button();
            this.btn43 = new System.Windows.Forms.Button();
            this.btn42 = new System.Windows.Forms.Button();
            this.btn41 = new System.Windows.Forms.Button();
            this.btn40 = new System.Windows.Forms.Button();
            this.btn39 = new System.Windows.Forms.Button();
            this.btn38 = new System.Windows.Forms.Button();
            this.btn37 = new System.Windows.Forms.Button();
            this.btn36 = new System.Windows.Forms.Button();
            this.btn35 = new System.Windows.Forms.Button();
            this.btn34 = new System.Windows.Forms.Button();
            this.btn33 = new System.Windows.Forms.Button();
            this.btn32 = new System.Windows.Forms.Button();
            this.btn31 = new System.Windows.Forms.Button();
            this.btn30 = new System.Windows.Forms.Button();
            this.btn29 = new System.Windows.Forms.Button();
            this.btn28 = new System.Windows.Forms.Button();
            this.btn27 = new System.Windows.Forms.Button();
            this.btn26 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn24 = new System.Windows.Forms.Button();
            this.btn23 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn19 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(1080, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 33);
            this.label1.TabIndex = 133;
            this.label1.Text = "Pontos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bauhaus 93", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(1080, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 33);
            this.label2.TabIndex = 134;
            this.label2.Text = "Elétrons";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bauhaus 93", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(104, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(440, 39);
            this.label3.TabIndex = 135;
            this.label3.Text = "Qual é o Símbolo Químico?";
            // 
            // txtElemento
            // 
            this.txtElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElemento.Location = new System.Drawing.Point(184, 96);
            this.txtElemento.Name = "txtElemento";
            this.txtElemento.ReadOnly = true;
            this.txtElemento.Size = new System.Drawing.Size(696, 44);
            this.txtElemento.TabIndex = 136;
            // 
            // txtPontos
            // 
            this.txtPontos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPontos.Location = new System.Drawing.Point(1216, 16);
            this.txtPontos.Name = "txtPontos";
            this.txtPontos.ReadOnly = true;
            this.txtPontos.Size = new System.Drawing.Size(104, 31);
            this.txtPontos.TabIndex = 137;
            this.txtPontos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEletron
            // 
            this.txtEletron.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEletron.Location = new System.Drawing.Point(1216, 56);
            this.txtEletron.Name = "txtEletron";
            this.txtEletron.ReadOnly = true;
            this.txtEletron.Size = new System.Drawing.Size(104, 31);
            this.txtEletron.TabIndex = 138;
            this.txtEletron.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnGeraElemento
            // 
            this.btnGeraElemento.BackColor = System.Drawing.Color.Transparent;
            this.btnGeraElemento.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGeraElemento.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnGeraElemento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGeraElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeraElemento.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnGeraElemento.Location = new System.Drawing.Point(184, 160);
            this.btnGeraElemento.Name = "btnGeraElemento";
            this.btnGeraElemento.Size = new System.Drawing.Size(200, 72);
            this.btnGeraElemento.TabIndex = 139;
            this.btnGeraElemento.Text = "Gerar Elemento";
            this.btnGeraElemento.UseVisualStyleBackColor = false;
            this.btnGeraElemento.Click += new System.EventHandler(this.btnGeraElemento_Click);
            // 
            // btn103
            // 
            this.btn103.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.laurencio;
            this.btn103.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn103.Location = new System.Drawing.Point(1176, 680);
            this.btn103.Name = "btn103";
            this.btn103.Size = new System.Drawing.Size(72, 72);
            this.btn103.TabIndex = 132;
            this.btn103.UseVisualStyleBackColor = true;
            this.btn103.Click += new System.EventHandler(this.btn103_Click);
            // 
            // btn102
            // 
            this.btn102.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.nobelio1;
            this.btn102.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn102.Location = new System.Drawing.Point(1104, 680);
            this.btn102.Name = "btn102";
            this.btn102.Size = new System.Drawing.Size(72, 72);
            this.btn102.TabIndex = 131;
            this.btn102.UseVisualStyleBackColor = true;
            this.btn102.Click += new System.EventHandler(this.btn102_Click);
            // 
            // btn101
            // 
            this.btn101.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.mendelevio;
            this.btn101.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn101.Location = new System.Drawing.Point(1032, 680);
            this.btn101.Name = "btn101";
            this.btn101.Size = new System.Drawing.Size(72, 72);
            this.btn101.TabIndex = 130;
            this.btn101.UseVisualStyleBackColor = true;
            this.btn101.Click += new System.EventHandler(this.btn101_Click);
            // 
            // btn100
            // 
            this.btn100.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.fermio;
            this.btn100.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn100.Location = new System.Drawing.Point(960, 680);
            this.btn100.Name = "btn100";
            this.btn100.Size = new System.Drawing.Size(72, 72);
            this.btn100.TabIndex = 129;
            this.btn100.UseVisualStyleBackColor = true;
            this.btn100.Click += new System.EventHandler(this.btn100_Click);
            // 
            // btn99
            // 
            this.btn99.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.einstenio;
            this.btn99.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn99.Location = new System.Drawing.Point(888, 680);
            this.btn99.Name = "btn99";
            this.btn99.Size = new System.Drawing.Size(72, 72);
            this.btn99.TabIndex = 128;
            this.btn99.UseVisualStyleBackColor = true;
            this.btn99.Click += new System.EventHandler(this.btn99_Click);
            // 
            // btn98
            // 
            this.btn98.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.californio;
            this.btn98.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn98.Location = new System.Drawing.Point(816, 680);
            this.btn98.Name = "btn98";
            this.btn98.Size = new System.Drawing.Size(72, 72);
            this.btn98.TabIndex = 127;
            this.btn98.UseVisualStyleBackColor = true;
            this.btn98.Click += new System.EventHandler(this.btn98_Click);
            // 
            // btn97
            // 
            this.btn97.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.berquelio;
            this.btn97.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn97.Location = new System.Drawing.Point(744, 680);
            this.btn97.Name = "btn97";
            this.btn97.Size = new System.Drawing.Size(72, 72);
            this.btn97.TabIndex = 126;
            this.btn97.UseVisualStyleBackColor = true;
            this.btn97.Click += new System.EventHandler(this.btn97_Click);
            // 
            // btn96
            // 
            this.btn96.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.curio;
            this.btn96.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn96.Location = new System.Drawing.Point(672, 680);
            this.btn96.Name = "btn96";
            this.btn96.Size = new System.Drawing.Size(72, 72);
            this.btn96.TabIndex = 125;
            this.btn96.UseVisualStyleBackColor = true;
            this.btn96.Click += new System.EventHandler(this.btn96_Click);
            // 
            // btn95
            // 
            this.btn95.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.americio;
            this.btn95.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn95.Location = new System.Drawing.Point(600, 680);
            this.btn95.Name = "btn95";
            this.btn95.Size = new System.Drawing.Size(72, 72);
            this.btn95.TabIndex = 124;
            this.btn95.UseVisualStyleBackColor = true;
            this.btn95.Click += new System.EventHandler(this.btn95_Click);
            // 
            // btn94
            // 
            this.btn94.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.plutonio;
            this.btn94.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn94.Location = new System.Drawing.Point(528, 680);
            this.btn94.Name = "btn94";
            this.btn94.Size = new System.Drawing.Size(72, 72);
            this.btn94.TabIndex = 123;
            this.btn94.UseVisualStyleBackColor = true;
            this.btn94.Click += new System.EventHandler(this.btn94_Click);
            // 
            // btn93
            // 
            this.btn93.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.neptunio;
            this.btn93.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn93.Location = new System.Drawing.Point(456, 680);
            this.btn93.Name = "btn93";
            this.btn93.Size = new System.Drawing.Size(72, 72);
            this.btn93.TabIndex = 122;
            this.btn93.UseVisualStyleBackColor = true;
            this.btn93.Click += new System.EventHandler(this.btn93_Click);
            // 
            // btn92
            // 
            this.btn92.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.uranio;
            this.btn92.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn92.Location = new System.Drawing.Point(384, 680);
            this.btn92.Name = "btn92";
            this.btn92.Size = new System.Drawing.Size(72, 72);
            this.btn92.TabIndex = 121;
            this.btn92.UseVisualStyleBackColor = true;
            this.btn92.Click += new System.EventHandler(this.btn92_Click);
            // 
            // btn91
            // 
            this.btn91.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.protactinio;
            this.btn91.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn91.Location = new System.Drawing.Point(312, 680);
            this.btn91.Name = "btn91";
            this.btn91.Size = new System.Drawing.Size(72, 72);
            this.btn91.TabIndex = 120;
            this.btn91.UseVisualStyleBackColor = true;
            this.btn91.Click += new System.EventHandler(this.btn91_Click);
            // 
            // btn90
            // 
            this.btn90.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.torio;
            this.btn90.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn90.Location = new System.Drawing.Point(240, 680);
            this.btn90.Name = "btn90";
            this.btn90.Size = new System.Drawing.Size(72, 72);
            this.btn90.TabIndex = 119;
            this.btn90.UseVisualStyleBackColor = true;
            this.btn90.Click += new System.EventHandler(this.btn90_Click);
            // 
            // btn89
            // 
            this.btn89.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.actinio;
            this.btn89.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn89.Location = new System.Drawing.Point(168, 680);
            this.btn89.Name = "btn89";
            this.btn89.Size = new System.Drawing.Size(72, 72);
            this.btn89.TabIndex = 118;
            this.btn89.UseVisualStyleBackColor = true;
            this.btn89.Click += new System.EventHandler(this.btn89_Click);
            // 
            // btn71
            // 
            this.btn71.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.lutecio;
            this.btn71.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn71.Location = new System.Drawing.Point(1176, 608);
            this.btn71.Name = "btn71";
            this.btn71.Size = new System.Drawing.Size(72, 72);
            this.btn71.TabIndex = 114;
            this.btn71.UseVisualStyleBackColor = true;
            this.btn71.Click += new System.EventHandler(this.btn71_Click);
            // 
            // btn70
            // 
            this.btn70.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.iterbio;
            this.btn70.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn70.Location = new System.Drawing.Point(1104, 608);
            this.btn70.Name = "btn70";
            this.btn70.Size = new System.Drawing.Size(72, 72);
            this.btn70.TabIndex = 113;
            this.btn70.UseVisualStyleBackColor = true;
            this.btn70.Click += new System.EventHandler(this.btn70_Click);
            // 
            // btn69
            // 
            this.btn69.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.tulio;
            this.btn69.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn69.Location = new System.Drawing.Point(1032, 608);
            this.btn69.Name = "btn69";
            this.btn69.Size = new System.Drawing.Size(72, 72);
            this.btn69.TabIndex = 112;
            this.btn69.UseVisualStyleBackColor = true;
            this.btn69.Click += new System.EventHandler(this.btn69_Click);
            // 
            // btn68
            // 
            this.btn68.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.erbio;
            this.btn68.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn68.Location = new System.Drawing.Point(960, 608);
            this.btn68.Name = "btn68";
            this.btn68.Size = new System.Drawing.Size(72, 72);
            this.btn68.TabIndex = 111;
            this.btn68.UseVisualStyleBackColor = true;
            this.btn68.Click += new System.EventHandler(this.btn68_Click);
            // 
            // btn67
            // 
            this.btn67.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.holmio;
            this.btn67.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn67.Location = new System.Drawing.Point(888, 608);
            this.btn67.Name = "btn67";
            this.btn67.Size = new System.Drawing.Size(72, 72);
            this.btn67.TabIndex = 110;
            this.btn67.UseVisualStyleBackColor = true;
            this.btn67.Click += new System.EventHandler(this.btn67_Click);
            // 
            // btn66
            // 
            this.btn66.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.disprosio;
            this.btn66.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn66.Location = new System.Drawing.Point(816, 608);
            this.btn66.Name = "btn66";
            this.btn66.Size = new System.Drawing.Size(72, 72);
            this.btn66.TabIndex = 109;
            this.btn66.UseVisualStyleBackColor = true;
            this.btn66.Click += new System.EventHandler(this.btn66_Click);
            // 
            // btn65
            // 
            this.btn65.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.terbio;
            this.btn65.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn65.Location = new System.Drawing.Point(744, 608);
            this.btn65.Name = "btn65";
            this.btn65.Size = new System.Drawing.Size(72, 72);
            this.btn65.TabIndex = 108;
            this.btn65.UseVisualStyleBackColor = true;
            this.btn65.Click += new System.EventHandler(this.btn65_Click);
            // 
            // btn64
            // 
            this.btn64.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.gadolinio;
            this.btn64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn64.Location = new System.Drawing.Point(672, 608);
            this.btn64.Name = "btn64";
            this.btn64.Size = new System.Drawing.Size(72, 72);
            this.btn64.TabIndex = 107;
            this.btn64.UseVisualStyleBackColor = true;
            this.btn64.Click += new System.EventHandler(this.btn64_Click);
            // 
            // btn63
            // 
            this.btn63.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.europio;
            this.btn63.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn63.Location = new System.Drawing.Point(600, 608);
            this.btn63.Name = "btn63";
            this.btn63.Size = new System.Drawing.Size(72, 72);
            this.btn63.TabIndex = 106;
            this.btn63.UseVisualStyleBackColor = true;
            this.btn63.Click += new System.EventHandler(this.btn63_Click);
            // 
            // btn62
            // 
            this.btn62.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.samario;
            this.btn62.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn62.Location = new System.Drawing.Point(528, 608);
            this.btn62.Name = "btn62";
            this.btn62.Size = new System.Drawing.Size(72, 72);
            this.btn62.TabIndex = 105;
            this.btn62.UseVisualStyleBackColor = true;
            this.btn62.Click += new System.EventHandler(this.btn62_Click);
            // 
            // btn61
            // 
            this.btn61.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.promecio;
            this.btn61.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn61.Location = new System.Drawing.Point(456, 608);
            this.btn61.Name = "btn61";
            this.btn61.Size = new System.Drawing.Size(72, 72);
            this.btn61.TabIndex = 104;
            this.btn61.UseVisualStyleBackColor = true;
            this.btn61.Click += new System.EventHandler(this.btn61_Click);
            // 
            // btn60
            // 
            this.btn60.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.neodiomio;
            this.btn60.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn60.Location = new System.Drawing.Point(384, 608);
            this.btn60.Name = "btn60";
            this.btn60.Size = new System.Drawing.Size(72, 72);
            this.btn60.TabIndex = 103;
            this.btn60.UseVisualStyleBackColor = true;
            this.btn60.Click += new System.EventHandler(this.btn60_Click);
            // 
            // btn59
            // 
            this.btn59.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.praseodimio;
            this.btn59.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn59.Location = new System.Drawing.Point(312, 608);
            this.btn59.Name = "btn59";
            this.btn59.Size = new System.Drawing.Size(72, 72);
            this.btn59.TabIndex = 102;
            this.btn59.UseVisualStyleBackColor = true;
            this.btn59.Click += new System.EventHandler(this.btn59_Click);
            // 
            // btn58
            // 
            this.btn58.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cerio;
            this.btn58.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn58.Location = new System.Drawing.Point(240, 608);
            this.btn58.Name = "btn58";
            this.btn58.Size = new System.Drawing.Size(72, 72);
            this.btn58.TabIndex = 101;
            this.btn58.UseVisualStyleBackColor = true;
            this.btn58.Click += new System.EventHandler(this.btn58_Click);
            // 
            // btn57
            // 
            this.btn57.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.lantanio;
            this.btn57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn57.Location = new System.Drawing.Point(168, 608);
            this.btn57.Name = "btn57";
            this.btn57.Size = new System.Drawing.Size(72, 72);
            this.btn57.TabIndex = 100;
            this.btn57.UseVisualStyleBackColor = true;
            this.btn57.Click += new System.EventHandler(this.btn57_Click);
            // 
            // btn118
            // 
            this.btn118.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.oganessonio;
            this.btn118.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn118.Location = new System.Drawing.Point(1248, 520);
            this.btn118.Name = "btn118";
            this.btn118.Size = new System.Drawing.Size(72, 72);
            this.btn118.TabIndex = 99;
            this.btn118.UseVisualStyleBackColor = true;
            this.btn118.Click += new System.EventHandler(this.btn118_Click);
            // 
            // btn117
            // 
            this.btn117.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.tenesso;
            this.btn117.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn117.Location = new System.Drawing.Point(1176, 520);
            this.btn117.Name = "btn117";
            this.btn117.Size = new System.Drawing.Size(72, 72);
            this.btn117.TabIndex = 98;
            this.btn117.UseVisualStyleBackColor = true;
            this.btn117.Click += new System.EventHandler(this.btn117_Click);
            // 
            // btn116
            // 
            this.btn116.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.livermorio;
            this.btn116.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn116.Location = new System.Drawing.Point(1104, 520);
            this.btn116.Name = "btn116";
            this.btn116.Size = new System.Drawing.Size(72, 72);
            this.btn116.TabIndex = 97;
            this.btn116.UseVisualStyleBackColor = true;
            this.btn116.Click += new System.EventHandler(this.btn116_Click);
            // 
            // btn115
            // 
            this.btn115.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.moscovio;
            this.btn115.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn115.Location = new System.Drawing.Point(1032, 520);
            this.btn115.Name = "btn115";
            this.btn115.Size = new System.Drawing.Size(72, 72);
            this.btn115.TabIndex = 96;
            this.btn115.UseVisualStyleBackColor = true;
            this.btn115.Click += new System.EventHandler(this.btn115_Click);
            // 
            // btn114
            // 
            this.btn114.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.flerovio;
            this.btn114.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn114.Location = new System.Drawing.Point(960, 520);
            this.btn114.Name = "btn114";
            this.btn114.Size = new System.Drawing.Size(72, 72);
            this.btn114.TabIndex = 95;
            this.btn114.UseVisualStyleBackColor = true;
            this.btn114.Click += new System.EventHandler(this.btn114_Click);
            // 
            // btn113
            // 
            this.btn113.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.nihonio1;
            this.btn113.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn113.Location = new System.Drawing.Point(888, 520);
            this.btn113.Name = "btn113";
            this.btn113.Size = new System.Drawing.Size(72, 72);
            this.btn113.TabIndex = 94;
            this.btn113.UseVisualStyleBackColor = true;
            this.btn113.Click += new System.EventHandler(this.btn113_Click);
            // 
            // btn112
            // 
            this.btn112.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.copernicio;
            this.btn112.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn112.Location = new System.Drawing.Point(816, 520);
            this.btn112.Name = "btn112";
            this.btn112.Size = new System.Drawing.Size(72, 72);
            this.btn112.TabIndex = 93;
            this.btn112.UseVisualStyleBackColor = true;
            this.btn112.Click += new System.EventHandler(this.btn112_Click);
            // 
            // btn111
            // 
            this.btn111.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.roentgenio;
            this.btn111.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn111.Location = new System.Drawing.Point(744, 520);
            this.btn111.Name = "btn111";
            this.btn111.Size = new System.Drawing.Size(72, 72);
            this.btn111.TabIndex = 92;
            this.btn111.UseVisualStyleBackColor = true;
            this.btn111.Click += new System.EventHandler(this.btn111_Click);
            // 
            // btn110
            // 
            this.btn110.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.darmstadtio;
            this.btn110.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn110.Location = new System.Drawing.Point(672, 520);
            this.btn110.Name = "btn110";
            this.btn110.Size = new System.Drawing.Size(72, 72);
            this.btn110.TabIndex = 91;
            this.btn110.UseVisualStyleBackColor = true;
            this.btn110.Click += new System.EventHandler(this.btn110_Click);
            // 
            // btn109
            // 
            this.btn109.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.mietnerio;
            this.btn109.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn109.Location = new System.Drawing.Point(600, 520);
            this.btn109.Name = "btn109";
            this.btn109.Size = new System.Drawing.Size(72, 72);
            this.btn109.TabIndex = 90;
            this.btn109.UseVisualStyleBackColor = true;
            this.btn109.Click += new System.EventHandler(this.btn109_Click);
            // 
            // btn108
            // 
            this.btn108.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.hassio;
            this.btn108.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn108.Location = new System.Drawing.Point(528, 520);
            this.btn108.Name = "btn108";
            this.btn108.Size = new System.Drawing.Size(72, 72);
            this.btn108.TabIndex = 89;
            this.btn108.UseVisualStyleBackColor = true;
            this.btn108.Click += new System.EventHandler(this.btn108_Click);
            // 
            // btn107
            // 
            this.btn107.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.bohrio;
            this.btn107.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn107.Location = new System.Drawing.Point(456, 520);
            this.btn107.Name = "btn107";
            this.btn107.Size = new System.Drawing.Size(72, 72);
            this.btn107.TabIndex = 88;
            this.btn107.UseVisualStyleBackColor = true;
            this.btn107.Click += new System.EventHandler(this.btn107_Click);
            // 
            // btn106
            // 
            this.btn106.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.seaborgio;
            this.btn106.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn106.Location = new System.Drawing.Point(384, 520);
            this.btn106.Name = "btn106";
            this.btn106.Size = new System.Drawing.Size(72, 72);
            this.btn106.TabIndex = 87;
            this.btn106.UseVisualStyleBackColor = true;
            this.btn106.Click += new System.EventHandler(this.btn106_Click);
            // 
            // btn105
            // 
            this.btn105.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.dubnio;
            this.btn105.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn105.Location = new System.Drawing.Point(312, 520);
            this.btn105.Name = "btn105";
            this.btn105.Size = new System.Drawing.Size(72, 72);
            this.btn105.TabIndex = 86;
            this.btn105.UseVisualStyleBackColor = true;
            this.btn105.Click += new System.EventHandler(this.btn105_Click);
            // 
            // btn104
            // 
            this.btn104.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.rutherfordio;
            this.btn104.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn104.Location = new System.Drawing.Point(240, 520);
            this.btn104.Name = "btn104";
            this.btn104.Size = new System.Drawing.Size(72, 72);
            this.btn104.TabIndex = 85;
            this.btn104.UseVisualStyleBackColor = true;
            this.btn104.Click += new System.EventHandler(this.btn104_Click);
            // 
            // btn88
            // 
            this.btn88.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.radio;
            this.btn88.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn88.Location = new System.Drawing.Point(96, 520);
            this.btn88.Name = "btn88";
            this.btn88.Size = new System.Drawing.Size(72, 72);
            this.btn88.TabIndex = 83;
            this.btn88.UseVisualStyleBackColor = true;
            this.btn88.Click += new System.EventHandler(this.btn88_Click);
            // 
            // btn87
            // 
            this.btn87.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.francio;
            this.btn87.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn87.Location = new System.Drawing.Point(24, 520);
            this.btn87.Name = "btn87";
            this.btn87.Size = new System.Drawing.Size(72, 72);
            this.btn87.TabIndex = 82;
            this.btn87.UseVisualStyleBackColor = true;
            this.btn87.Click += new System.EventHandler(this.btn87_Click);
            // 
            // btn86
            // 
            this.btn86.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.radonio;
            this.btn86.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn86.Location = new System.Drawing.Point(1248, 448);
            this.btn86.Name = "btn86";
            this.btn86.Size = new System.Drawing.Size(72, 72);
            this.btn86.TabIndex = 81;
            this.btn86.UseVisualStyleBackColor = true;
            this.btn86.Click += new System.EventHandler(this.btn86_Click);
            // 
            // btn85
            // 
            this.btn85.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.astato;
            this.btn85.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn85.Location = new System.Drawing.Point(1176, 448);
            this.btn85.Name = "btn85";
            this.btn85.Size = new System.Drawing.Size(72, 72);
            this.btn85.TabIndex = 80;
            this.btn85.UseVisualStyleBackColor = true;
            this.btn85.Click += new System.EventHandler(this.btn85_Click);
            // 
            // btn84
            // 
            this.btn84.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.polonio;
            this.btn84.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn84.Location = new System.Drawing.Point(1104, 448);
            this.btn84.Name = "btn84";
            this.btn84.Size = new System.Drawing.Size(72, 72);
            this.btn84.TabIndex = 79;
            this.btn84.UseVisualStyleBackColor = true;
            this.btn84.Click += new System.EventHandler(this.btn84_Click);
            // 
            // btn83
            // 
            this.btn83.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.bismuto;
            this.btn83.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn83.Location = new System.Drawing.Point(1032, 448);
            this.btn83.Name = "btn83";
            this.btn83.Size = new System.Drawing.Size(72, 72);
            this.btn83.TabIndex = 78;
            this.btn83.UseVisualStyleBackColor = true;
            this.btn83.Click += new System.EventHandler(this.btn83_Click);
            // 
            // btn82
            // 
            this.btn82.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.chumbo;
            this.btn82.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn82.Location = new System.Drawing.Point(960, 448);
            this.btn82.Name = "btn82";
            this.btn82.Size = new System.Drawing.Size(72, 72);
            this.btn82.TabIndex = 77;
            this.btn82.UseVisualStyleBackColor = true;
            this.btn82.Click += new System.EventHandler(this.btn82_Click);
            // 
            // btn81
            // 
            this.btn81.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.talio;
            this.btn81.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn81.Location = new System.Drawing.Point(888, 448);
            this.btn81.Name = "btn81";
            this.btn81.Size = new System.Drawing.Size(72, 72);
            this.btn81.TabIndex = 76;
            this.btn81.UseVisualStyleBackColor = true;
            this.btn81.Click += new System.EventHandler(this.btn81_Click);
            // 
            // btn80
            // 
            this.btn80.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.mercurio;
            this.btn80.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn80.Location = new System.Drawing.Point(816, 448);
            this.btn80.Name = "btn80";
            this.btn80.Size = new System.Drawing.Size(72, 72);
            this.btn80.TabIndex = 75;
            this.btn80.UseVisualStyleBackColor = true;
            this.btn80.Click += new System.EventHandler(this.btn80_Click);
            // 
            // btn79
            // 
            this.btn79.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.ouro;
            this.btn79.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn79.Location = new System.Drawing.Point(744, 448);
            this.btn79.Name = "btn79";
            this.btn79.Size = new System.Drawing.Size(72, 72);
            this.btn79.TabIndex = 74;
            this.btn79.UseVisualStyleBackColor = true;
            this.btn79.Click += new System.EventHandler(this.btn79_Click);
            // 
            // btn78
            // 
            this.btn78.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.platina;
            this.btn78.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn78.Location = new System.Drawing.Point(672, 448);
            this.btn78.Name = "btn78";
            this.btn78.Size = new System.Drawing.Size(72, 72);
            this.btn78.TabIndex = 73;
            this.btn78.UseVisualStyleBackColor = true;
            this.btn78.Click += new System.EventHandler(this.btn78_Click);
            // 
            // btn77
            // 
            this.btn77.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.iridio;
            this.btn77.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn77.Location = new System.Drawing.Point(600, 448);
            this.btn77.Name = "btn77";
            this.btn77.Size = new System.Drawing.Size(72, 72);
            this.btn77.TabIndex = 72;
            this.btn77.UseVisualStyleBackColor = true;
            this.btn77.Click += new System.EventHandler(this.btn77_Click);
            // 
            // btn76
            // 
            this.btn76.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.osmio;
            this.btn76.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn76.Location = new System.Drawing.Point(528, 448);
            this.btn76.Name = "btn76";
            this.btn76.Size = new System.Drawing.Size(72, 72);
            this.btn76.TabIndex = 71;
            this.btn76.UseVisualStyleBackColor = true;
            this.btn76.Click += new System.EventHandler(this.btn76_Click);
            // 
            // btn75
            // 
            this.btn75.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.renio;
            this.btn75.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn75.Location = new System.Drawing.Point(456, 448);
            this.btn75.Name = "btn75";
            this.btn75.Size = new System.Drawing.Size(72, 72);
            this.btn75.TabIndex = 70;
            this.btn75.UseVisualStyleBackColor = true;
            this.btn75.Click += new System.EventHandler(this.btn75_Click);
            // 
            // btn74
            // 
            this.btn74.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.tungstenio;
            this.btn74.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn74.Location = new System.Drawing.Point(384, 448);
            this.btn74.Name = "btn74";
            this.btn74.Size = new System.Drawing.Size(72, 72);
            this.btn74.TabIndex = 69;
            this.btn74.UseVisualStyleBackColor = true;
            this.btn74.Click += new System.EventHandler(this.btn74_Click);
            // 
            // btn73
            // 
            this.btn73.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.tantalo;
            this.btn73.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn73.Location = new System.Drawing.Point(312, 448);
            this.btn73.Name = "btn73";
            this.btn73.Size = new System.Drawing.Size(72, 72);
            this.btn73.TabIndex = 68;
            this.btn73.UseVisualStyleBackColor = true;
            this.btn73.Click += new System.EventHandler(this.btn73_Click);
            // 
            // btn72
            // 
            this.btn72.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.hafnio;
            this.btn72.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn72.Location = new System.Drawing.Point(240, 448);
            this.btn72.Name = "btn72";
            this.btn72.Size = new System.Drawing.Size(72, 72);
            this.btn72.TabIndex = 67;
            this.btn72.UseVisualStyleBackColor = true;
            this.btn72.Click += new System.EventHandler(this.btn72_Click);
            // 
            // btn56
            // 
            this.btn56.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.bario;
            this.btn56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn56.Location = new System.Drawing.Point(96, 448);
            this.btn56.Name = "btn56";
            this.btn56.Size = new System.Drawing.Size(72, 72);
            this.btn56.TabIndex = 65;
            this.btn56.UseVisualStyleBackColor = true;
            this.btn56.Click += new System.EventHandler(this.btn56_Click);
            // 
            // btn55
            // 
            this.btn55.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cesio;
            this.btn55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn55.Location = new System.Drawing.Point(24, 448);
            this.btn55.Name = "btn55";
            this.btn55.Size = new System.Drawing.Size(72, 72);
            this.btn55.TabIndex = 64;
            this.btn55.UseVisualStyleBackColor = true;
            this.btn55.Click += new System.EventHandler(this.btn55_Click);
            // 
            // btn54
            // 
            this.btn54.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.xenonio;
            this.btn54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn54.Location = new System.Drawing.Point(1248, 376);
            this.btn54.Name = "btn54";
            this.btn54.Size = new System.Drawing.Size(72, 72);
            this.btn54.TabIndex = 63;
            this.btn54.UseVisualStyleBackColor = true;
            this.btn54.Click += new System.EventHandler(this.btn54_Click);
            // 
            // btn53
            // 
            this.btn53.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.iodo;
            this.btn53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn53.Location = new System.Drawing.Point(1176, 376);
            this.btn53.Name = "btn53";
            this.btn53.Size = new System.Drawing.Size(72, 72);
            this.btn53.TabIndex = 62;
            this.btn53.UseVisualStyleBackColor = true;
            this.btn53.Click += new System.EventHandler(this.btn53_Click);
            // 
            // btn52
            // 
            this.btn52.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.telurio;
            this.btn52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn52.Location = new System.Drawing.Point(1104, 376);
            this.btn52.Name = "btn52";
            this.btn52.Size = new System.Drawing.Size(72, 72);
            this.btn52.TabIndex = 61;
            this.btn52.UseVisualStyleBackColor = true;
            this.btn52.Click += new System.EventHandler(this.btn52_Click);
            // 
            // btn51
            // 
            this.btn51.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.antimonio;
            this.btn51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn51.Location = new System.Drawing.Point(1032, 376);
            this.btn51.Name = "btn51";
            this.btn51.Size = new System.Drawing.Size(72, 72);
            this.btn51.TabIndex = 60;
            this.btn51.UseVisualStyleBackColor = true;
            this.btn51.Click += new System.EventHandler(this.btn51_Click);
            // 
            // button50
            // 
            this.button50.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.estanho;
            this.button50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button50.Location = new System.Drawing.Point(960, 376);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(72, 72);
            this.button50.TabIndex = 59;
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // btn49
            // 
            this.btn49.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.indio;
            this.btn49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn49.Location = new System.Drawing.Point(888, 376);
            this.btn49.Name = "btn49";
            this.btn49.Size = new System.Drawing.Size(72, 72);
            this.btn49.TabIndex = 58;
            this.btn49.UseVisualStyleBackColor = true;
            this.btn49.Click += new System.EventHandler(this.btn49_Click);
            // 
            // btn48
            // 
            this.btn48.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cadmio;
            this.btn48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn48.Location = new System.Drawing.Point(816, 376);
            this.btn48.Name = "btn48";
            this.btn48.Size = new System.Drawing.Size(72, 72);
            this.btn48.TabIndex = 57;
            this.btn48.UseVisualStyleBackColor = true;
            this.btn48.Click += new System.EventHandler(this.btn48_Click);
            // 
            // btn47
            // 
            this.btn47.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.prata;
            this.btn47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn47.Location = new System.Drawing.Point(744, 376);
            this.btn47.Name = "btn47";
            this.btn47.Size = new System.Drawing.Size(72, 72);
            this.btn47.TabIndex = 56;
            this.btn47.UseVisualStyleBackColor = true;
            this.btn47.Click += new System.EventHandler(this.btn47_Click);
            // 
            // btn46
            // 
            this.btn46.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.paladio;
            this.btn46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn46.Location = new System.Drawing.Point(672, 376);
            this.btn46.Name = "btn46";
            this.btn46.Size = new System.Drawing.Size(72, 72);
            this.btn46.TabIndex = 55;
            this.btn46.UseVisualStyleBackColor = true;
            this.btn46.Click += new System.EventHandler(this.btn46_Click);
            // 
            // btn45
            // 
            this.btn45.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.rodio;
            this.btn45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn45.Location = new System.Drawing.Point(600, 376);
            this.btn45.Name = "btn45";
            this.btn45.Size = new System.Drawing.Size(72, 72);
            this.btn45.TabIndex = 54;
            this.btn45.UseVisualStyleBackColor = true;
            this.btn45.Click += new System.EventHandler(this.btn45_Click);
            // 
            // btn44
            // 
            this.btn44.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.rutenio;
            this.btn44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn44.Location = new System.Drawing.Point(528, 376);
            this.btn44.Name = "btn44";
            this.btn44.Size = new System.Drawing.Size(72, 72);
            this.btn44.TabIndex = 53;
            this.btn44.UseVisualStyleBackColor = true;
            this.btn44.Click += new System.EventHandler(this.btn44_Click);
            // 
            // btn43
            // 
            this.btn43.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.tecnecio;
            this.btn43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn43.Location = new System.Drawing.Point(456, 376);
            this.btn43.Name = "btn43";
            this.btn43.Size = new System.Drawing.Size(72, 72);
            this.btn43.TabIndex = 52;
            this.btn43.UseVisualStyleBackColor = true;
            this.btn43.Click += new System.EventHandler(this.btn43_Click);
            // 
            // btn42
            // 
            this.btn42.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.molibdenio;
            this.btn42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn42.Location = new System.Drawing.Point(384, 376);
            this.btn42.Name = "btn42";
            this.btn42.Size = new System.Drawing.Size(72, 72);
            this.btn42.TabIndex = 51;
            this.btn42.UseVisualStyleBackColor = true;
            this.btn42.Click += new System.EventHandler(this.btn42_Click);
            // 
            // btn41
            // 
            this.btn41.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.niobio;
            this.btn41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn41.Location = new System.Drawing.Point(312, 376);
            this.btn41.Name = "btn41";
            this.btn41.Size = new System.Drawing.Size(72, 72);
            this.btn41.TabIndex = 50;
            this.btn41.UseVisualStyleBackColor = true;
            this.btn41.Click += new System.EventHandler(this.btn41_Click);
            // 
            // btn40
            // 
            this.btn40.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.zirconio;
            this.btn40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn40.Location = new System.Drawing.Point(240, 376);
            this.btn40.Name = "btn40";
            this.btn40.Size = new System.Drawing.Size(72, 72);
            this.btn40.TabIndex = 49;
            this.btn40.UseVisualStyleBackColor = true;
            this.btn40.Click += new System.EventHandler(this.btn40_Click);
            // 
            // btn39
            // 
            this.btn39.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.itrio;
            this.btn39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn39.Location = new System.Drawing.Point(168, 376);
            this.btn39.Name = "btn39";
            this.btn39.Size = new System.Drawing.Size(72, 72);
            this.btn39.TabIndex = 48;
            this.btn39.UseVisualStyleBackColor = true;
            this.btn39.Click += new System.EventHandler(this.btn39_Click);
            // 
            // btn38
            // 
            this.btn38.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.estroncio;
            this.btn38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn38.Location = new System.Drawing.Point(96, 376);
            this.btn38.Name = "btn38";
            this.btn38.Size = new System.Drawing.Size(72, 72);
            this.btn38.TabIndex = 47;
            this.btn38.UseVisualStyleBackColor = true;
            this.btn38.Click += new System.EventHandler(this.btn38_Click);
            // 
            // btn37
            // 
            this.btn37.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.rubidio;
            this.btn37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn37.Location = new System.Drawing.Point(24, 376);
            this.btn37.Name = "btn37";
            this.btn37.Size = new System.Drawing.Size(72, 72);
            this.btn37.TabIndex = 46;
            this.btn37.UseVisualStyleBackColor = true;
            this.btn37.Click += new System.EventHandler(this.btn37_Click);
            // 
            // btn36
            // 
            this.btn36.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.criptonio;
            this.btn36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn36.Location = new System.Drawing.Point(1248, 304);
            this.btn36.Name = "btn36";
            this.btn36.Size = new System.Drawing.Size(72, 72);
            this.btn36.TabIndex = 45;
            this.btn36.UseVisualStyleBackColor = true;
            this.btn36.Click += new System.EventHandler(this.btn36_Click);
            // 
            // btn35
            // 
            this.btn35.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.bromo;
            this.btn35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn35.Location = new System.Drawing.Point(1176, 304);
            this.btn35.Name = "btn35";
            this.btn35.Size = new System.Drawing.Size(72, 72);
            this.btn35.TabIndex = 44;
            this.btn35.UseVisualStyleBackColor = true;
            this.btn35.Click += new System.EventHandler(this.btn35_Click);
            // 
            // btn34
            // 
            this.btn34.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.selenio;
            this.btn34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn34.Location = new System.Drawing.Point(1104, 304);
            this.btn34.Name = "btn34";
            this.btn34.Size = new System.Drawing.Size(72, 72);
            this.btn34.TabIndex = 43;
            this.btn34.UseVisualStyleBackColor = true;
            this.btn34.Click += new System.EventHandler(this.btn34_Click);
            // 
            // btn33
            // 
            this.btn33.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.arsenio;
            this.btn33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn33.Location = new System.Drawing.Point(1032, 304);
            this.btn33.Name = "btn33";
            this.btn33.Size = new System.Drawing.Size(72, 72);
            this.btn33.TabIndex = 42;
            this.btn33.UseVisualStyleBackColor = true;
            this.btn33.Click += new System.EventHandler(this.btn33_Click);
            // 
            // btn32
            // 
            this.btn32.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.germanio;
            this.btn32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn32.Location = new System.Drawing.Point(960, 304);
            this.btn32.Name = "btn32";
            this.btn32.Size = new System.Drawing.Size(72, 72);
            this.btn32.TabIndex = 41;
            this.btn32.UseVisualStyleBackColor = true;
            this.btn32.Click += new System.EventHandler(this.btn32_Click);
            // 
            // btn31
            // 
            this.btn31.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.galio;
            this.btn31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn31.Location = new System.Drawing.Point(888, 304);
            this.btn31.Name = "btn31";
            this.btn31.Size = new System.Drawing.Size(72, 72);
            this.btn31.TabIndex = 40;
            this.btn31.UseVisualStyleBackColor = true;
            this.btn31.Click += new System.EventHandler(this.btn31_Click);
            // 
            // btn30
            // 
            this.btn30.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.zinco;
            this.btn30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn30.Location = new System.Drawing.Point(816, 304);
            this.btn30.Name = "btn30";
            this.btn30.Size = new System.Drawing.Size(72, 72);
            this.btn30.TabIndex = 39;
            this.btn30.UseVisualStyleBackColor = true;
            this.btn30.Click += new System.EventHandler(this.btn30_Click);
            // 
            // btn29
            // 
            this.btn29.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cobre;
            this.btn29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn29.Location = new System.Drawing.Point(744, 304);
            this.btn29.Name = "btn29";
            this.btn29.Size = new System.Drawing.Size(72, 72);
            this.btn29.TabIndex = 38;
            this.btn29.UseVisualStyleBackColor = true;
            this.btn29.Click += new System.EventHandler(this.btn29_Click);
            // 
            // btn28
            // 
            this.btn28.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.niquel;
            this.btn28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn28.Location = new System.Drawing.Point(672, 304);
            this.btn28.Name = "btn28";
            this.btn28.Size = new System.Drawing.Size(72, 72);
            this.btn28.TabIndex = 37;
            this.btn28.UseVisualStyleBackColor = true;
            this.btn28.Click += new System.EventHandler(this.btn28_Click);
            // 
            // btn27
            // 
            this.btn27.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cobalto;
            this.btn27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn27.Location = new System.Drawing.Point(600, 304);
            this.btn27.Name = "btn27";
            this.btn27.Size = new System.Drawing.Size(72, 72);
            this.btn27.TabIndex = 36;
            this.btn27.UseVisualStyleBackColor = true;
            this.btn27.Click += new System.EventHandler(this.btn27_Click);
            // 
            // btn26
            // 
            this.btn26.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.ferro;
            this.btn26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn26.Location = new System.Drawing.Point(528, 304);
            this.btn26.Name = "btn26";
            this.btn26.Size = new System.Drawing.Size(72, 72);
            this.btn26.TabIndex = 35;
            this.btn26.UseVisualStyleBackColor = true;
            this.btn26.Click += new System.EventHandler(this.btn26_Click);
            // 
            // btn25
            // 
            this.btn25.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.manganes;
            this.btn25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn25.Location = new System.Drawing.Point(456, 304);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(72, 72);
            this.btn25.TabIndex = 34;
            this.btn25.UseVisualStyleBackColor = true;
            this.btn25.Click += new System.EventHandler(this.btn25_Click);
            // 
            // btn24
            // 
            this.btn24.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cromio;
            this.btn24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn24.Location = new System.Drawing.Point(384, 304);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(72, 72);
            this.btn24.TabIndex = 33;
            this.btn24.UseVisualStyleBackColor = true;
            this.btn24.Click += new System.EventHandler(this.btn24_Click);
            // 
            // btn23
            // 
            this.btn23.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.vanadio;
            this.btn23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn23.Location = new System.Drawing.Point(312, 304);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(72, 72);
            this.btn23.TabIndex = 32;
            this.btn23.UseVisualStyleBackColor = true;
            this.btn23.Click += new System.EventHandler(this.btn23_Click);
            // 
            // btn22
            // 
            this.btn22.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.titanio;
            this.btn22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn22.Location = new System.Drawing.Point(240, 304);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(72, 72);
            this.btn22.TabIndex = 31;
            this.btn22.UseVisualStyleBackColor = true;
            this.btn22.Click += new System.EventHandler(this.btn22_Click);
            // 
            // btn21
            // 
            this.btn21.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.scandio;
            this.btn21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn21.Location = new System.Drawing.Point(168, 304);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(72, 72);
            this.btn21.TabIndex = 30;
            this.btn21.UseVisualStyleBackColor = true;
            this.btn21.Click += new System.EventHandler(this.btn21_Click);
            // 
            // btn20
            // 
            this.btn20.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.calcio;
            this.btn20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn20.Location = new System.Drawing.Point(96, 304);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(72, 72);
            this.btn20.TabIndex = 29;
            this.btn20.UseVisualStyleBackColor = true;
            this.btn20.Click += new System.EventHandler(this.btn20_Click);
            // 
            // btn19
            // 
            this.btn19.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.potassio;
            this.btn19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn19.Location = new System.Drawing.Point(24, 304);
            this.btn19.Name = "btn19";
            this.btn19.Size = new System.Drawing.Size(72, 72);
            this.btn19.TabIndex = 28;
            this.btn19.UseVisualStyleBackColor = true;
            this.btn19.Click += new System.EventHandler(this.btn19_Click);
            // 
            // btn18
            // 
            this.btn18.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.argonio;
            this.btn18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn18.Location = new System.Drawing.Point(1248, 232);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(72, 72);
            this.btn18.TabIndex = 27;
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Click += new System.EventHandler(this.btn18_Click);
            // 
            // btn17
            // 
            this.btn17.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.cloro;
            this.btn17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn17.Location = new System.Drawing.Point(1176, 232);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(72, 72);
            this.btn17.TabIndex = 26;
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Click += new System.EventHandler(this.btn17_Click);
            // 
            // btn16
            // 
            this.btn16.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.enxofre;
            this.btn16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn16.Location = new System.Drawing.Point(1104, 232);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(72, 72);
            this.btn16.TabIndex = 25;
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Click += new System.EventHandler(this.btn16_Click);
            // 
            // btn15
            // 
            this.btn15.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.fosforo;
            this.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn15.Location = new System.Drawing.Point(1032, 232);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(72, 72);
            this.btn15.TabIndex = 24;
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Click += new System.EventHandler(this.btn15_Click);
            // 
            // btn14
            // 
            this.btn14.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.silicio;
            this.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn14.Location = new System.Drawing.Point(960, 232);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(72, 72);
            this.btn14.TabIndex = 23;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Click += new System.EventHandler(this.btn14_Click);
            // 
            // btn13
            // 
            this.btn13.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.aluminio;
            this.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn13.Location = new System.Drawing.Point(888, 232);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(72, 72);
            this.btn13.TabIndex = 22;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Click += new System.EventHandler(this.btn13_Click);
            // 
            // btn12
            // 
            this.btn12.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.magnesio;
            this.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn12.Location = new System.Drawing.Point(96, 232);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(72, 72);
            this.btn12.TabIndex = 11;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn11
            // 
            this.btn11.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.sodio;
            this.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn11.Location = new System.Drawing.Point(24, 232);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(72, 72);
            this.btn11.TabIndex = 10;
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn10
            // 
            this.btn10.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.neonio;
            this.btn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn10.Location = new System.Drawing.Point(1248, 160);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(72, 72);
            this.btn10.TabIndex = 9;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn9
            // 
            this.btn9.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.fluor;
            this.btn9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn9.Location = new System.Drawing.Point(1176, 160);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(72, 72);
            this.btn9.TabIndex = 8;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.oxigenio;
            this.btn8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn8.Location = new System.Drawing.Point(1104, 160);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(72, 72);
            this.btn8.TabIndex = 7;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn7
            // 
            this.btn7.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.nitrogenio;
            this.btn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn7.Location = new System.Drawing.Point(1032, 160);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(72, 72);
            this.btn7.TabIndex = 6;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.carbono;
            this.btn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn6.Location = new System.Drawing.Point(960, 160);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(72, 72);
            this.btn6.TabIndex = 5;
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.boro;
            this.btn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn5.Location = new System.Drawing.Point(888, 160);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(72, 72);
            this.btn5.TabIndex = 4;
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.berilio;
            this.btn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn4.Location = new System.Drawing.Point(96, 160);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(72, 72);
            this.btn4.TabIndex = 3;
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.litio;
            this.btn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn3.Location = new System.Drawing.Point(24, 160);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(72, 72);
            this.btn3.TabIndex = 2;
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.helio;
            this.btn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn2.Location = new System.Drawing.Point(1248, 88);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(72, 72);
            this.btn2.TabIndex = 1;
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.BackgroundImage = global::JogoTabelaPeriódica.Properties.Resources.hidrogenio;
            this.btn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn1.Location = new System.Drawing.Point(24, 88);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(72, 72);
            this.btn1.TabIndex = 0;
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Jogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1347, 781);
            this.Controls.Add(this.btnGeraElemento);
            this.Controls.Add(this.txtEletron);
            this.Controls.Add(this.txtPontos);
            this.Controls.Add(this.txtElemento);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn103);
            this.Controls.Add(this.btn102);
            this.Controls.Add(this.btn101);
            this.Controls.Add(this.btn100);
            this.Controls.Add(this.btn99);
            this.Controls.Add(this.btn98);
            this.Controls.Add(this.btn97);
            this.Controls.Add(this.btn96);
            this.Controls.Add(this.btn95);
            this.Controls.Add(this.btn94);
            this.Controls.Add(this.btn93);
            this.Controls.Add(this.btn92);
            this.Controls.Add(this.btn91);
            this.Controls.Add(this.btn90);
            this.Controls.Add(this.btn89);
            this.Controls.Add(this.btn71);
            this.Controls.Add(this.btn70);
            this.Controls.Add(this.btn69);
            this.Controls.Add(this.btn68);
            this.Controls.Add(this.btn67);
            this.Controls.Add(this.btn66);
            this.Controls.Add(this.btn65);
            this.Controls.Add(this.btn64);
            this.Controls.Add(this.btn63);
            this.Controls.Add(this.btn62);
            this.Controls.Add(this.btn61);
            this.Controls.Add(this.btn60);
            this.Controls.Add(this.btn59);
            this.Controls.Add(this.btn58);
            this.Controls.Add(this.btn57);
            this.Controls.Add(this.btn118);
            this.Controls.Add(this.btn117);
            this.Controls.Add(this.btn116);
            this.Controls.Add(this.btn115);
            this.Controls.Add(this.btn114);
            this.Controls.Add(this.btn113);
            this.Controls.Add(this.btn112);
            this.Controls.Add(this.btn111);
            this.Controls.Add(this.btn110);
            this.Controls.Add(this.btn109);
            this.Controls.Add(this.btn108);
            this.Controls.Add(this.btn107);
            this.Controls.Add(this.btn106);
            this.Controls.Add(this.btn105);
            this.Controls.Add(this.btn104);
            this.Controls.Add(this.btn88);
            this.Controls.Add(this.btn87);
            this.Controls.Add(this.btn86);
            this.Controls.Add(this.btn85);
            this.Controls.Add(this.btn84);
            this.Controls.Add(this.btn83);
            this.Controls.Add(this.btn82);
            this.Controls.Add(this.btn81);
            this.Controls.Add(this.btn80);
            this.Controls.Add(this.btn79);
            this.Controls.Add(this.btn78);
            this.Controls.Add(this.btn77);
            this.Controls.Add(this.btn76);
            this.Controls.Add(this.btn75);
            this.Controls.Add(this.btn74);
            this.Controls.Add(this.btn73);
            this.Controls.Add(this.btn72);
            this.Controls.Add(this.btn56);
            this.Controls.Add(this.btn55);
            this.Controls.Add(this.btn54);
            this.Controls.Add(this.btn53);
            this.Controls.Add(this.btn52);
            this.Controls.Add(this.btn51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.btn49);
            this.Controls.Add(this.btn48);
            this.Controls.Add(this.btn47);
            this.Controls.Add(this.btn46);
            this.Controls.Add(this.btn45);
            this.Controls.Add(this.btn44);
            this.Controls.Add(this.btn43);
            this.Controls.Add(this.btn42);
            this.Controls.Add(this.btn41);
            this.Controls.Add(this.btn40);
            this.Controls.Add(this.btn39);
            this.Controls.Add(this.btn38);
            this.Controls.Add(this.btn37);
            this.Controls.Add(this.btn36);
            this.Controls.Add(this.btn35);
            this.Controls.Add(this.btn34);
            this.Controls.Add(this.btn33);
            this.Controls.Add(this.btn32);
            this.Controls.Add(this.btn31);
            this.Controls.Add(this.btn30);
            this.Controls.Add(this.btn29);
            this.Controls.Add(this.btn28);
            this.Controls.Add(this.btn27);
            this.Controls.Add(this.btn26);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.btn24);
            this.Controls.Add(this.btn23);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.btn21);
            this.Controls.Add(this.btn20);
            this.Controls.Add(this.btn19);
            this.Controls.Add(this.btn18);
            this.Controls.Add(this.btn17);
            this.Controls.Add(this.btn16);
            this.Controls.Add(this.btn15);
            this.Controls.Add(this.btn14);
            this.Controls.Add(this.btn13);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Jogo";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jogo";
            this.Load += new System.EventHandler(this.Jogo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn18;
        private System.Windows.Forms.Button btn17;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn36;
        private System.Windows.Forms.Button btn35;
        private System.Windows.Forms.Button btn34;
        private System.Windows.Forms.Button btn33;
        private System.Windows.Forms.Button btn32;
        private System.Windows.Forms.Button btn31;
        private System.Windows.Forms.Button btn30;
        private System.Windows.Forms.Button btn29;
        private System.Windows.Forms.Button btn28;
        private System.Windows.Forms.Button btn27;
        private System.Windows.Forms.Button btn26;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button btn24;
        private System.Windows.Forms.Button btn23;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn19;
        private System.Windows.Forms.Button btn54;
        private System.Windows.Forms.Button btn53;
        private System.Windows.Forms.Button btn52;
        private System.Windows.Forms.Button btn51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button btn49;
        private System.Windows.Forms.Button btn48;
        private System.Windows.Forms.Button btn47;
        private System.Windows.Forms.Button btn46;
        private System.Windows.Forms.Button btn45;
        private System.Windows.Forms.Button btn44;
        private System.Windows.Forms.Button btn43;
        private System.Windows.Forms.Button btn42;
        private System.Windows.Forms.Button btn41;
        private System.Windows.Forms.Button btn40;
        private System.Windows.Forms.Button btn39;
        private System.Windows.Forms.Button btn38;
        private System.Windows.Forms.Button btn37;
        private System.Windows.Forms.Button btn86;
        private System.Windows.Forms.Button btn85;
        private System.Windows.Forms.Button btn84;
        private System.Windows.Forms.Button btn83;
        private System.Windows.Forms.Button btn82;
        private System.Windows.Forms.Button btn81;
        private System.Windows.Forms.Button btn80;
        private System.Windows.Forms.Button btn79;
        private System.Windows.Forms.Button btn78;
        private System.Windows.Forms.Button btn77;
        private System.Windows.Forms.Button btn76;
        private System.Windows.Forms.Button btn75;
        private System.Windows.Forms.Button btn74;
        private System.Windows.Forms.Button btn73;
        private System.Windows.Forms.Button btn72;
        private System.Windows.Forms.Button btn56;
        private System.Windows.Forms.Button btn55;
        private System.Windows.Forms.Button btn118;
        private System.Windows.Forms.Button btn117;
        private System.Windows.Forms.Button btn116;
        private System.Windows.Forms.Button btn115;
        private System.Windows.Forms.Button btn114;
        private System.Windows.Forms.Button btn113;
        private System.Windows.Forms.Button btn112;
        private System.Windows.Forms.Button btn111;
        private System.Windows.Forms.Button btn110;
        private System.Windows.Forms.Button btn109;
        private System.Windows.Forms.Button btn108;
        private System.Windows.Forms.Button btn107;
        private System.Windows.Forms.Button btn106;
        private System.Windows.Forms.Button btn105;
        private System.Windows.Forms.Button btn104;
        private System.Windows.Forms.Button btn88;
        private System.Windows.Forms.Button btn87;
        private System.Windows.Forms.Button btn71;
        private System.Windows.Forms.Button btn70;
        private System.Windows.Forms.Button btn69;
        private System.Windows.Forms.Button btn68;
        private System.Windows.Forms.Button btn67;
        private System.Windows.Forms.Button btn66;
        private System.Windows.Forms.Button btn65;
        private System.Windows.Forms.Button btn64;
        private System.Windows.Forms.Button btn63;
        private System.Windows.Forms.Button btn62;
        private System.Windows.Forms.Button btn61;
        private System.Windows.Forms.Button btn60;
        private System.Windows.Forms.Button btn59;
        private System.Windows.Forms.Button btn58;
        private System.Windows.Forms.Button btn57;
        private System.Windows.Forms.Button btn103;
        private System.Windows.Forms.Button btn102;
        private System.Windows.Forms.Button btn101;
        private System.Windows.Forms.Button btn100;
        private System.Windows.Forms.Button btn99;
        private System.Windows.Forms.Button btn98;
        private System.Windows.Forms.Button btn97;
        private System.Windows.Forms.Button btn96;
        private System.Windows.Forms.Button btn95;
        private System.Windows.Forms.Button btn94;
        private System.Windows.Forms.Button btn93;
        private System.Windows.Forms.Button btn92;
        private System.Windows.Forms.Button btn91;
        private System.Windows.Forms.Button btn90;
        private System.Windows.Forms.Button btn89;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtElemento;
        private System.Windows.Forms.TextBox txtPontos;
        private System.Windows.Forms.TextBox txtEletron;
        private System.Windows.Forms.Button btnGeraElemento;
    }
}