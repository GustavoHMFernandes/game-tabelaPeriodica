﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace JogoTabelaPeriódica
{
    public partial class Jogo : Form
    {
        //Variaveis Eletrons, Pontos, Atomo, Simbolo
        string nome;
        int E = 8;
        int P = 0;
        int At, Simb;
        //Cria um random
        Random random = new Random();       

        public Jogo()
        {
            InitializeComponent();
            Task.Run(() => musica());
        }
        private void Jogo_Load(object sender, EventArgs e)
        {
            txtPontos.Text = (P.ToString());
            txtEletron.Text = (E.ToString());
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 2;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 3;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 4;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 5;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 6;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 7;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 8;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 9;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 10;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn11_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 11;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn12_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 12;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn13_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 13;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn14_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 14;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn15_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 15;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn16_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 16;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn17_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 17;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn18_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 18;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn19_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 19;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn20_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 20;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn21_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 21;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn22_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 22;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn23_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 23;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn24_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 24;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn25_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 25;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn26_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 26;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn27_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 27;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn28_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 28;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn29_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 29;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn30_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 30;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn31_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 31;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn32_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 32;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn33_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 33;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn34_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 34;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn35_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 35;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn36_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 36;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn37_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 37;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn38_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 38;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn39_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 39;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn40_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 40;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn41_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 41;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn42_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 42;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn43_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 43;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn44_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 44;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn45_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 45;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn46_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 46;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn47_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 47;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn48_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 48;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn49_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 49;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void button50_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 50;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn51_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 51;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn52_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 52;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn53_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 53;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn54_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 54;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn55_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 55;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn56_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 56;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn57_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 57;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn58_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 58;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn59_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 59;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn60_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 60;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn61_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 61;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn62_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 62;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn63_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 63;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn64_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 64;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn65_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 65;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn66_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 66;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn67_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 67;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn68_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 68;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn69_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 69;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn70_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 70;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn71_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 71;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn72_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 72;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn73_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 73;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn74_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 74;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn75_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 75;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn76_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 76;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn77_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 77;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn78_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 78;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn79_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 79;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn80_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 80;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn81_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 81;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn82_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 82;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn83_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 83;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn84_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 84;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn85_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 85;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn86_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 86;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn87_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 87;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn88_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 88;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn89_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 89;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn90_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 90;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn91_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 91;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn92_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 92;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn93_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 93;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn94_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 94;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn95_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 95;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn96_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 96;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn97_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 97;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn98_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 98;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn99_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 99;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn100_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 100;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn101_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 101;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn102_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 102;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn103_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 103;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn104_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 104;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn105_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 105;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn106_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 106;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn107_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 107;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn108_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 108;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn109_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 109;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn111_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 111;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn110_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 110;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn112_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 112;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn113_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 113;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn114_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 114;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn115_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 115;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn116_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 116;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn117_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 117;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btn118_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 118;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }

        private void btnGeraElemento_Click(object sender, EventArgs e)
        {
           
            //define valor do random e define a variável
            E = E - 1;
            txtEletron.Text = (E.ToString());       
            At = random.Next(1, 119);
            if(E>=0)
            {
                //switc case nos diz qual o nome do elemento foi escolhido
                switch (At)
                {
                    case (1):
                        nome = "Hidrogênio";
                        break;
                    case (2):
                        nome = "Hélio";
                        break;
                    case (3):
                        nome = "Lítio";
                        break;
                    case (4):
                        nome = "Berílio";
                        break;
                    case (5):
                        nome = "Boro";
                        break;
                    case (6):
                        nome = "Carbono";
                        break;
                    case (7):
                        nome = "Nitrogênio";
                        break;
                    case (8):
                        nome = "Oxigênio";
                        break;
                    case (9):
                        nome = "Flúor";
                        break;
                    case (10):
                        nome = "Neônio";
                        break;
                    //-------------------10-------------------
                    case (11):
                        nome = "Sódio";
                        break;
                    case (12):
                        nome = "Magnésio";
                        break;
                    case (13):
                        nome = "Alumínio";
                        break;
                    case (14):
                        nome = "Silício";
                        break;
                    case (15):
                        nome = "Fósforo";
                        break;
                    case (16):
                        nome = "Enxofre";
                        break;
                    case (17):
                        nome = "Cloro";
                        break;
                    case (18):
                        nome = "Argônio";
                        break;
                    case (19):
                        nome = "Potássio";
                        break;
                    case (20):
                        nome = "Cálcio";
                        break;
                    //-------------------20-------------------
                    case (21):
                        nome = "Escândio";
                        break;
                    case (22):
                        nome = "Titânio";
                        break;
                    case (23):
                        nome = "Vanádio";
                        break;
                    case (24):
                        nome = "Crômio";
                        break;
                    case (25):
                        nome = "Manganês";
                        break;
                    case (26):
                        nome = "Ferro";
                        break;
                    case (27):
                        nome = "Cobalto";
                        break;
                    case (28):
                        nome = "Níquel";
                        break;
                    case (29):
                        nome = "Cobre";
                        break;
                    case (30):
                        nome = "Zinco";
                        break;
                    //-------------------30-------------------
                    case (31):
                        nome = "Gálio";
                        break;
                    case (32):
                        nome = "Germânio";
                        break;
                    case (33):
                        nome = "Arsênio";
                        break;
                    case (34):
                        nome = "Selênio";
                        break;
                    case (35):
                        nome = "Bromo";
                        break;
                    case (36):
                        nome = "Criptônio";
                        break;
                    case (37):
                        nome = "Rubídio";
                        break;
                    case (38):
                        nome = "Estrôncio";
                        break;
                    case (39):
                        nome = "Ítrio";
                        break;
                    case (40):
                        nome = "Zircônio";
                        break;
                    //-------------------40-------------------
                    case (41):
                        nome = "Nióbio";
                        break;
                    case (42):
                        nome = "Molibdênio";
                        break;
                    case (43):
                        nome = "Tecnécio";
                        break;
                    case (44):
                        nome = "Rutênio";
                        break;
                    case (45):
                        nome = "Ródio";
                        break;
                    case (46):
                        nome = "Paládio";
                        break;
                    case (47):
                        nome = "Prata";
                        break;
                    case (48):
                        nome = "Cádmio";
                        break;
                    case (49):
                        nome = "Índio";
                        break;
                    case (50):
                        nome = "Estanho";
                        break;
                    //-------------------50-------------------
                    case (51):
                        nome = "Antimônio";
                        break;
                    case (52):
                        nome = "Telúrio";
                        break;
                    case (53):
                        nome = "Iodo";
                        break;
                    case (54):
                        nome = "Xenônio";
                        break;
                    case (55):
                        nome = "Césio";
                        break;
                    case (56):
                        nome = "Bário";
                        break;
                    case (57):
                        nome = "Lantânio";
                        break;
                    case (58):
                        nome = "Cério";
                        break;
                    case (59):
                        nome = "Praseodímio";
                        break;
                    case (60):
                        nome = "Neodímio";
                        break;
                    //-------------------60-------------------
                    case (61):
                        nome = "Promécio";
                        break;
                    case (62):
                        nome = "Samário";
                        break;
                    case (63):
                        nome = "Európio";
                        break;
                    case (64):
                        nome = "Gadolínio";
                        break;
                    case (65):
                        nome = "Térbio";
                        break;
                    case (66):
                        nome = "Disprósio";
                        break;
                    case (67):
                        nome = "Hôlmio";
                        break;
                    case (68):
                        nome = "Érbio";
                        break;
                    case (69):
                        nome = "Túlio";
                        break;
                    case (70):
                        nome = "Itérbio";
                        break;
                    //-------------------70-------------------
                    case (71):
                        nome = "Lutécio";
                        break;
                    case (72):
                        nome = "Háfnio";
                        break;
                    case (73):
                        nome = "Tântalo";
                        break;
                    case (74):
                        nome = "Tungstênio";
                        break;
                    case (75):
                        nome = "Rênio";
                        break;
                    case (76):
                        nome = "Ósmio";
                        break;
                    case (77):
                        nome = "Irídio";
                        break;
                    case (78):
                        nome = "Platina";
                        break;
                    case (79):
                        nome = "Ouro";
                        break;
                    case (80):
                        nome = "Mercúrio";
                        break;
                    //-------------------80-------------------
                    case (81):
                        nome = "Tálio";
                        break;
                    case (82):
                        nome = "Chumbo";
                        break;
                    case (83):
                        nome = "Bismuto";
                        break;
                    case (84):
                        nome = "Polônio";
                        break;
                    case (85):
                        nome = "Astato";
                        break;
                    case (86):
                        nome = "Radônio";
                        break;
                    case (87):
                        nome = "Frâncio";
                        break;
                    case (88):
                        nome = "Rádio";
                        break;
                    case (89):
                        nome = "Actínio";
                        break;
                    case (90):
                        nome = "Tório";
                        break;
                    //-------------------90-------------------
                    case (91):
                        nome = "Protactínio";
                        break;
                    case (92):
                        nome = "Urânio";
                        break;
                    case (93):
                        nome = "Neptúnio";
                        break;
                    case (94):
                        nome = "Plutônio";
                        break;
                    case (95):
                        nome = "Amerício";
                        break;
                    case (96):
                        nome = "Cúrio";
                        break;
                    case (97):
                        nome = "Berquélio";
                        break;
                    case (98):
                        nome = "Califórnio";
                        break;
                    case (99):
                        nome = "Einstênio";
                        break;
                    case (100):
                        nome = "Férmio";
                        break;
                    //-------------------100-------------------
                    case (101):
                        nome = "Mendelévio";
                        break;
                    case (102):
                        nome = "Nobélio";
                        break;
                    case (103):
                        nome = "Laurêncio";
                        break;
                    case (104):
                        nome = "Rutherfórdio";
                        break;
                    case (105):
                        nome = "Dúbnio";
                        break;
                    case (106):
                        nome = "Seabórgio";
                        break;
                    case (107):
                        nome = "Bóhrio";
                        break;
                    case (108):
                        nome = "Hássio";
                        break;
                    case (109):
                        nome = "Meitnério";
                        break;
                    case (110):
                        nome = "Darmstádtio";
                        break;
                    //-------------------110------------------- case (1):
                    case (111):
                        nome = "Roentgênio";
                        break;
                    case (112):
                        nome = "Copernício";
                        break;
                    case (113):
                        nome = "Nihônio";
                        break;
                    case (114):
                        nome = "Fleróvio";
                        break;
                    case (115):
                        nome = "Moscóvio";
                        break;
                    case (116):
                        nome = "Livermório";
                        break;
                    case (117):
                        nome = "Tennesso";
                        break;
                    case (118):
                        nome = "Oganessônio";
                        break;
                    //-------------------118-------------------
                    default:
                        nome = "";
                        break;
                }
            }
            else
            {
                nome = "";
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            
            txtElemento.Text = nome;
         
        }

        private void musica()
        {
            SoundPlayer music = new SoundPlayer(@"e:\Tales\soundeffect\scifi.wav");
            music.Play();
        }


        private void btn1_Click(object sender, EventArgs e)
        {
            //botao click atribui valor do simbolo
            Simb = 1;
            //compara valor do simbolo com o valor do atomo que foi gerado
            if (E >= 0)
            {
                if (At == Simb)
                {
                    P = P + 1;
                    E = E + 1;
                    txtPontos.Text = (P.ToString());
                    txtEletron.Text = (E.ToString());
                }
            }
            else
            {
                this.Hide();
                Rank sistema = new Rank();
                sistema.ShowDialog();
                this.Close();
            }
            nome = "";
            At = 0;
            txtElemento.Text = nome;
        }
    }
}
